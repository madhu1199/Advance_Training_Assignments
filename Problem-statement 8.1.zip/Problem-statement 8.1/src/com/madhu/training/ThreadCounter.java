package com.madhu.training;

public class ThreadCounter {
	
	public static void main(String[] args) {
		Counter counter = new Counter(50);

		counter.run();


	}


}

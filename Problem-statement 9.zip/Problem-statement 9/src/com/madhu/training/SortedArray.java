package com.madhu.training;

import java.util.HashMap;

public class SortedArray {
	
	public static void main(String[] args) {
		int[] arr = {2, 2, 2, 4, 4, 5, 5, 6, 8, 8, 9};
		for (int i=0; i<arr.length;i++) {
        }
        HashMap<Integer, Integer> freqMap = solveIterative(arr);
 
        for(int value : freqMap.keySet())
        {
            System.out.println(value + " occurs " + freqMap.get(value)+ " times");
        }
 
    }
 
    public static HashMap<Integer, Integer> solveIterative(int[] arr)
    {
        HashMap<Integer, Integer> freqMap = new HashMap<>();
        for(int value : arr)
        {
            if(!freqMap.containsKey(value))
            {
                freqMap.put(value, 1);
            }
            else {
                freqMap.put(value, freqMap.get(value)+1);
            }
        }   
        return freqMap;

	}

}
